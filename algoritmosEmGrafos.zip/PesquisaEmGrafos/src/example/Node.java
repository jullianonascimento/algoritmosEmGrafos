package example;

public class Node {
	public char label;
	public boolean visited = false;

	public Node(char l) {
		this.label = l;
	}
}
